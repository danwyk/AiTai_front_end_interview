# AiTai Front-end Coding Interview
### Credit to YIKAI WANG
